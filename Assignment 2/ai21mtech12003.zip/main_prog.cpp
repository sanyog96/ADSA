#include<iostream>
#include <math.h>
#include <cmath>
#include <bits/stdc++.h>
#include <vector>
#include <string>
#include <utility>
#include <limits>
using namespace std;

//Checking whether words array is lexicographically sorted
//input:
//      words: array of words
//output:
//      True is returned if sorted lexicographically otherwise False
bool checkSortedWordOrder(vector<string> words){
    bool flag = true;
    for(int i = 1; i < words.size(); i++){
        if(words[i].compare(words[i-1]) < 0){
            flag = false;
            return flag;
        }
    }
    return flag;
}

//Checking whether probability array have distinct values or not
//input:
//      prob: array of probability of words in words array
//output:
//      True is returned if number of distinct values in array is equal to size of array otherwise False
bool checkDistinctProb(vector<double> prob){
    unordered_set<double> p;
    for(int i = 0; i < prob.size(); i++){
        p.insert(prob[i]);
    }
    if(p.size() == prob.size()){
        return true;
    } else {
        return false;
    }
}

//Checking whether sum of probabilities in prob array is 1
//input:
//      prob: array of probability of words in words array
//output:
//      True is returned if sum of probability is 1 otherwise False
bool checkProbSum(vector<double> prob){
    double sum = 0;
    for(int i = 0; i < prob.size(); i++){
        sum += prob[i];
    }
    if(abs(sum - 1) < 1e-9){
        return true;
    } else {
        return false;
    }
}

//creates a probability matrix that keeps total sum of prob between index i to j from prob array
//input:
//      prob: array of probability of words in words array
//output:
//      2 dimensional matrix whose upper triangle is filled and other values are 0
vector<vector<double>> initializeProbMatrix(vector<double> prob){
    int n = prob.size();
    vector<vector<double>> prob_matrix(n + 1);
    for(int i = 0; i < n+1; i++){
        prob_matrix[i] = vector<double>(n+1, 0);
    }
    for(int i = 1; i < n+1; i++){
        for(int j = i; j < n+1; j++){
            prob_matrix[i][j] = prob_matrix[i][j-1] + prob[j-1];
        }
    }
    return prob_matrix;
}

//prints root node of array between i to j
//input:
//      words: array of words
//      root_node_matrix: two dimensional array in which element at (i,j) is root node for elements from index i to index j in words array
//      i: row index for root_node_matrix
//      j: column index for root_node_matrix
//output:
//      traverse words array in preorder format
void preorderTraversal(vector<string> words, vector<vector<int>> root_node_matrix, int i, int j){
    int root_index = root_node_matrix[i][j];
    cout<<words[root_index - 1]<<" ";
    if(i <= root_index - 1){
        preorderTraversal(words, root_node_matrix, i, root_index - 1);
    }
    if(root_index + 1 <= j){
        preorderTraversal(words, root_node_matrix, root_index + 1, j);
    }
}

//prints root node of array between i to j
//input:
//      words: array of words
//      prob: array of probability of words in words array
void optimalBST(vector<string> words, vector<double> prob){
    int n = prob.size();

    //generating probability matrix for having sum of probabilities from one index to another
    vector<vector<double>> prob_matrix = initializeProbMatrix(prob);

    vector<vector<double>> optimal_cost_matrix(n + 2);
    vector<vector<int>> root_node_matrix(n+2);

    for(int i = 0; i < n+2; i++){
        optimal_cost_matrix[i] = vector<double>(n + 1, FLT_MAX);
        root_node_matrix[i] = vector<int>(n+1, 0);
    }
    for(int i = 1; i < n+2; i++){
        optimal_cost_matrix[i][i-1] = 0;
    }

    //logic to get optimal root node between two indexes of words and optimal cost to generate the BST for that subarray
    for(int k = 0; k <= n-1; k++){
        for(int i = 1; i <= n-k; i++){
            int start_index = i;
            int end_index= i+k;
            for(int j = start_index; j < end_index + 1; j++){
                if((optimal_cost_matrix[start_index][j-1] + optimal_cost_matrix[j+1][end_index]) < optimal_cost_matrix[start_index][end_index]){
                    optimal_cost_matrix[start_index][end_index] = (optimal_cost_matrix[start_index][j-1] + optimal_cost_matrix[j+1][end_index]);
                    root_node_matrix[start_index][end_index] = j;
                }
            }
            optimal_cost_matrix[start_index][end_index] = optimal_cost_matrix[start_index][end_index] + prob_matrix[start_index][end_index];
        }
    }

    cout<<"The minimum expected total access time is "<<optimal_cost_matrix[1][n]<<".";

    cout<<"\nPreorder traversal of the BST that provides minimum expected total access time is: \n";
    preorderTraversal(words, root_node_matrix, 1, n);
}

//main function
int main(){
    int n;
    cout<<"How many strings do you want to insert in the BST? ";
    cin>>n;
    vector<string> words;
    vector<double> prob;
    cout<<"Enter "<<n<<" strings in sorted dictionary order along with their probabilities: ";
    string temp_word;
    double temp_prob;
    for(int i = 0; i < n; i++){
        cin >> temp_word;
        cin >> temp_prob;
        words.push_back(temp_word);
        prob.push_back(temp_prob);
    }
    /*
    vector<string> words {"a", "am", "and", "egg", "if", "the", "two"};
    vector<double> prob {0.22, 0.18, 0.2, 0.05, 0.25, 0.02, 0.08};
    int n = prob.size();
    */
    string error = "";
    bool flag = false;
    if(!checkSortedWordOrder(words)){
        flag = true;
        string temp_error = "The strings entered are not in sorted order. ";
        error = error + temp_error;
    }

    if(!checkDistinctProb(prob)){
        flag = true;
        string temp_error = "The probabilities are not distinct. ";
        error = error + temp_error;
    }

    if(!checkProbSum(prob)){
        flag = true;
        string temp_error = "The probabilities don\`t add up to 1. ";
        error = error + temp_error;
    }

    if(!flag){
        optimalBST(words, prob);
    } else {
        cout<<error;
    }

    return 0;
}
