#include<iostream>
#include <math.h>
#include <cmath>
#include <bits/stdc++.h>
#include <vector>
#include <string>
#include <utility>
#include <limits>
#include <fstream>
#include <sstream>
#include <unistd.h>
using namespace std;

#define INF 99999

void printParent(vector<int> parent, int n){
    cout<<"parent : ";
    for(int i = 0; i < n; i++){
        cout<<parent[i]<<" ";
    }
    cout<<endl;
}

void printMSTCost(vector<int> parent, vector<vector<int>> mat, int n)
{
    cout<<endl;
    int sum = 0;
    for (int i = 0; i < n; i++){
        if(parent[i] == -1){
            continue;
        }
        sum += mat[i][parent[i]];
    }
    cout<<"The cost of MST formed is: "<<sum<<endl;
}

//prints neighbours of vertices used to create tree
//input:
//      parent: parent array from prims algorithm
//      next: next vertex 2 dimensional array from floyd warshall shortest path algorithm function
//      required_vertices: required vertices to be present in tree
//      n: number of vertices
//output:
//      neighbours of vertices present in the tree
void printMST(vector<int> parent, vector<vector<int>> next, vector<int> required_vertices, int n, vector<vector<int>> mat){
    vector<bool> update_flag(n, false);
    unordered_set<int> final_set;
    int source_node = required_vertices[0];
    final_set.insert(source_node);
    for(int i = 0; i < required_vertices.size(); i++){
        int pos = required_vertices[i];
        if(parent[pos] == -1 && pos == source_node){
            update_flag[pos] = true;
        }
        if(parent[pos] != -1){
            final_set.insert(pos);
            if(next[parent[pos]][pos] == pos){
                update_flag[pos] = true;
                continue;
            } else {
                while(next[parent[pos]][pos] != pos){
                    int temp = parent[pos];
                    parent[pos] = next[temp][pos];
                    if(update_flag[parent[pos]] == false){
                        parent[parent[pos]] = temp;
                        final_set.insert(parent[pos]);
                        update_flag[parent[pos]] = true;
                    }
                }
                update_flag[pos] = true;
            }
        }
    }
    cout << "The 2-factor approximate tree we have computed is given below (we describe this tree by listing all the neighbors of all the vertices in the tree): \n";
    for(int i = 0; i < n; i++){
        if(final_set.find(i) != final_set.end()){
            cout<<"Neighbors of Vertex "<<(i+1)<<": ";
            unordered_set<int> temp_set;
            for(int j = 0; j < n; j++){
                if(i == j){
                    if(parent[j] == -1){
                        continue;
                    } else {
                        int node = parent[j] + 1;
                        if(temp_set.find(node) == temp_set.end()){
                            temp_set.insert(node);
                            cout<<node<<" ";
                        }
                    }
                } else {
                    if(parent[j] == i){
                        int node = j + 1;
                        if(temp_set.find(node) == temp_set.end()){
                            temp_set.insert(node);
                            cout<<node<<" ";
                        }
                    } else {
                        continue;
                    }
                }
            }
            cout<<endl;
        }
    }
    printMSTCost(parent, mat, n);
}

//getting minimum cost connected vertex which has not yet been visited
//input:
//      key: current cost array to each vertex
//      mstSet: bool vector that stores whether current vertex was visited or not
//      n: number of vertices
//output:
//      index of minimum cost connected vertex
int minKey(vector<int> key, vector<bool> mstSet, int n){
    int min_val = INT_MAX;
    int min_index;
    for(int i = 0; i < n; i++){
        if(mstSet[i] == false && key[i] < min_val){
            min_val = key[i];
            min_index = i;
        }
    }
    return min_index;
}

//generates a minimum spanning tree from input graph
//input:
//      A: complete graph matrix
//      next: next vertex 2 dimensional array from floyd warshall shortest path algorithm function
//      required_vertices: required vertices to be present in tree
//      n: number of vertices
void prims(vector<vector<int>> A, vector<vector<int>> next, vector<int> required_vertices, int n, vector<vector<int>> mat){
    vector<int> parent(n);
    vector<int> key(n);
    vector<bool> mstSet(n);
    for(int i = 0; i < n; i++){
        key[i] = INT_MAX;
        mstSet[i] = false;
        parent[i] = -1;
    }
    int initial_node = required_vertices[0];
    key[initial_node] = 0;
    parent[initial_node] = -1;
    for(int i = 0; i < n - 1; i++){
        int u = minKey(key, mstSet, n);
        std::vector<int>::iterator it = std::find(required_vertices.begin(), required_vertices.end(), u);
        if(it != required_vertices.end()){
            mstSet[u] = true;
            for(int v = 0; v < n; v++){
                std::vector<int>::iterator it1 = std::find(required_vertices.begin(), required_vertices.end(), v);
                if(it1 != required_vertices.end()){
                    if(A[u][v] && mstSet[v] == false && A[u][v] < key[v]){
                        parent[v] = u;
                        key[v] = A[u][v];
                    }
                }
            }
        }
    }
    printMST(parent, next, required_vertices, n, mat);
}

//generates all vertex shortest path from given graph
//input:
//      mat: input graph
//      required_vertices: required vertices to be present in tree
//      n: number of vertices
void floydWarshall(vector<vector<int>> mat, int n, vector<int> required_vertices){
    vector<vector<int>> A(n);
    vector<vector<int>> next(n);
    int i, j, k;
    for(i = 0; i < n; i++){
        A[i] = vector<int> (n);
        next[i] = vector<int> (n);
        for(j = 0; j < n; j++){
            if(i != j && mat[i][j] == 0){
                A[i][j] = INF;
                next[i][j] = -1;
            } else {
                A[i][j] = mat[i][j];
                next[i][j] = j;
            }
        }
    }
    for(k = 0; k < n; k++){
        for(i = 0; i < n; i++){
            for(j = 0; j < n; j++){
                if(A[i][j] > (A[i][k] + A[k][j]) && (A[k][j] != INF && A[i][k] != INF)){
                    A[i][j] = A[i][k] + A[k][j];
                    next[i][j] = next[i][k];
                }
            }
        }
    }
    prims(A, next, required_vertices, n, mat);
}

//main function
int main(){
    string filename;
    ifstream fin;
    char current_path[PATH_MAX];
    getcwd(current_path, sizeof(current_path));
    string path = current_path;
    path = path + "\\";
    cout<<"Please enter filename: ";
    getline(cin, filename);
    //filename = path + filename;
    fin.open(filename.c_str());
    int n = 0;
    float m = 0;
    if(fin) {
        string line;
        string cont_string;
        while(getline(fin, line)){
            if(line.empty()){
                continue;
            } else {
                for(int i = 0; i < line.size(); i++){
                    if(line[i] == ' '){
                        m++;
                    }
                }
                m++;
                if(n == 0){
                    cont_string = line;
                } else {
                    cont_string = cont_string + "\n";
                    cont_string = cont_string + line;
                }
                n++;
            }
        }
        if(n != 0){
            m = m/n;
            if(m == n){
                istringstream content(cont_string);
                vector<vector<int>> mat(n);
                for(int i = 0; i < n; i++){
                    mat[i] = vector<int> (n, 0);
                    for(int j = 0; j <n; j++){
                        content >> mat[i][j];
                    }
                }
                cout<<"The input matrix A the program read from the file is displayed below: \n";
                for(int i = 0; i < n; i++){
                    for(int j = 0; j < n; j++){
                        cout<<mat[i][j]<<" ";
                    }
                    cout<<endl;
                }
                vector<int> steiner_vertices;
                vector<int> required_vertices;
                for(int i = 0; i < n; i++){
                    required_vertices.push_back(i);
                }
                bool flag = true;
                cout<<"List all the Steiner vertices (type * to quit): \n";
                while(flag){
                    string temp;
                    cin>>temp;
                    if(temp == "*"){
                        flag = false;
                    } else if(stoi(temp) > 0 && stoi(temp) <= n){
                        int temp_int = stoi(temp) - 1;
                        steiner_vertices.push_back(temp_int);
                        std::vector<int>::iterator it = std::find(required_vertices.begin(), required_vertices.end(), temp_int);
                        required_vertices.erase(it);
                    } else {
                        cout<<"Above vertex is out of range of number of vertices. Please enter those which are between 1 and "<<n<<endl;
                    }
                }
                if(required_vertices.size() == 0){
                    cout<<"Number of required vertices should be greater than 0 to get neighbours."<<endl;
                } else if(required_vertices.size() == 1) {
                    cout<<"Required vertices has only one node " <<(required_vertices[0]+1)<<" with no neighbour."<<endl;
                } else {
                    floydWarshall(mat, n, required_vertices);
                }
            } else {
                cout<<"number of rows and columns of matrix are not equal."<<endl;
            }
        } else {
            cout<<"file is empty."<<endl;
        }
    } else {
        cout<<"file doesn't exist."<<endl;
    }
    return 0;
}
