#include<iostream>
#include <math.h>
#include <cmath>
#include <bits/stdc++.h>
#include <vector>
using namespace std;

#define MAX_DEGREE 15

//print polynomial function prints in decreasing degree structure
//input:
//      deg: degree of the polynomial
//      poly: array of coefficients of polynomial in increasing order of degree
void print_poly(int deg, vector<double> poly){
    int t = deg;
    //printing highest degree part first with sign - if negative otherwise
    //no sign for positive
    while(t > 0){
        if(poly[t] == 0){
            t--;
            continue;
        } else {
            if(abs(poly[t]) != 1){
                if(poly[t] < 0){
                    cout<<"- "<<abs(poly[t])<<"x*"<<t<<" ";
                } else {
                    if(poly[t] > 0){
                        cout<<poly[t]<<"x*"<<t<<" ";
                    }
                }
            } else {
                if(poly[t] < 0){
                    cout<<"- "<<"x*"<<t<<" ";
                } else {
                    cout<<"x*"<<t<<" ";
                }
            }
            break;
        }
    }

    //degrees between highest degree and constant
    for(int i = t-1; i >= 1; i--){
        if(poly[i] == 0){
            continue;
        } else {
            if(poly[i] < 0){
                if(poly[i] == -1){
                    cout<<"- "<<"x*"<<i<<" ";
                } else {
                    cout<<"- "<<abs(poly[i])<<"x*"<<i<<" ";
                }
            } else {
                if(poly[i] == 1){
                    cout<<"+ "<<"x*"<<i<<" ";
                } else {
                    cout<<"+ "<<poly[i]<<"x*"<<i<<" ";
                }
            }
        }
    }

    //constant in the polynomial
    if(poly[0] != 0){
        if(poly[0] < 0){
            cout<<"- "<<abs(poly[0]);
        } else {
            cout<<"+ "<<abs(poly[0]);
        }
    }

    cout<<"\n";
}

//naive polynomial multiplication with complexity O(n^2)
//input:
//      deg_1: degree of first polynomial
//      deg_2: degree of second polynomial
//      poly_1: array of coefficient of first polynomial in increasing order of degree
//      poly_2: array of coefficient of second polynomial in increasing order of degree
//output:
//      coefficients of resultant polynomial after multiplication
vector<double> naive_polynomial_multiplication(int deg_1, int deg_2, vector<double> poly_1, vector<double> poly_2){
    vector<double> naive_poly(2*MAX_DEGREE + 2, 0);

    for(int i = 0; i < 2*MAX_DEGREE + 2; i++){
        naive_poly[i] = 0;
    }

    for(int i = 0; i <= deg_1; i++){
        for(int j = 0; j <= deg_2; j++){
            naive_poly[i+j] += poly_1[i]*poly_2[j];
        }
    }
    return naive_poly;
}

//function for adding complex number
//input:
//      a: real part of first complex number
//      b: complex part of first complex number
//      c: real part of second complex number
//      d: complex part of second complex number
//output:
//      resultant complex number array of dimension 2 with first element as real
//      and second element as complex part
vector<double> add_complex_num(double a, double b, double c, double d){
    vector<double> sum(2, 0);
    sum[0] = a + c;
    sum[1] = b + d;
    return sum;
}

//function for multiplying complex number
//input:
//      a: real part of first complex number
//      b: complex part of first complex number
//      c: real part of second complex number
//      d: complex part of second complex number
//output:
//      resultant complex number array of dimension 2 with first element as real
//      and second element as complex part
vector<double> multiply_complex_num(double a, double b, double c, double d){
    vector<double> mult(2, 0);
    mult[0] = a*c - b*d;
    mult[1] = a*d + b*c;
    return mult;
}

//function for finding nearest power of 2 compared to given degrees of polynomial
//input:
//      deg_1: degree of first polynomial
//      deg_2: degree of second polynomial
//output:
//      resultant power of 2
int find_N(int deg_1, int deg_2){
    return pow(2, ceil(log2(deg_1 + deg_2 + 1)));
}

//function for Nth roots of unity
//input:
//      N: value of N for finding Nth roots
//      flag: true if inverse of V matrix is required otherwise false
//output:
//      resultant roots 2D array with real parts and complex parts
vector<vector<double>> find_complex_roots(int N, bool flag){
    vector<vector<double>> roots(N);
    if(flag){

        //for inverse of V matrix while calculation
        for(int i = 0; i < N; i++){
            roots[i] = vector<double>(2);
            if (i == 0){
                roots[i][0] = cos((2*M_PI*i)/N);
                roots[i][1] = sin((2*M_PI*i)/N);
            } else {
                roots[i][0] = cos((2*M_PI*(N-i))/N);
                roots[i][1] = sin((2*M_PI*(N-i))/N);
            }
        }
    } else {

        //for V matrix direct usage
        for(int i = 0; i < N; i++){
            roots[i] = vector<double>(2);
            roots[i][0] = cos((2*M_PI*i)/N);
            roots[i][1] = sin((2*M_PI*i)/N);
        }
    }
    return roots;
}

//Converting input polynomial coefficients as 2D array with complex part as 0
//input:
//      poly: array of coefficients of polynomial
//output:
//      resultant 2D array with real parts and complex parts for coefficients of
//      polynomial
vector<vector<double>> convert_complex(vector<double> poly){
    vector<vector<double>> temp(poly.size());

    for(int i = 0; i < poly.size(); i++){
        temp[i] = vector<double>(2);
        temp[i][0] = poly[i];
        temp[i][1] = 0;
    }
    return temp;
}

//Eval functon for calculation of output array using V matrix and input
//input:
//      poly: array of coefficients of polynomial
//      N: maximum possible degree of output product polynomial
//      flag: true when we find the final coefficients of product polynomial
//              for using V^(-1) otherwise false
//output:
//      resultant 2D array with real parts and complex parts
vector<vector<double>> Eval(vector<vector<double>> poly, int N, bool flag){
    //base case
    if(N == 1){
        vector<vector<double>> y(1);
        y[0] = vector<double>(2);
        y[0][0] = poly[0][0];
        y[0][1] = poly[0][1];
        return y;
    }

    vector<vector<double>> roots = find_complex_roots(N, flag);

    //breaking polynomial into two parts A0 and A1
    vector<vector<double>> A0(N/2), A1(N/2);
    for(int i = 0; i < N/2; i++){
        A0[i] = poly[2*i];
        A1[i] = poly[2*i + 1];
    }

    //recursion part
    vector<vector<double>> y0 = Eval(A0, N/2, flag);
    vector<vector<double>> y1 = Eval(A1, N/2, flag);

    vector<vector<double>> y(N);
    for(int i = 0; i < N/2; i++){
        vector<double> temp1 = multiply_complex_num(roots[i][0], roots[i][1], y1[i][0], y1[i][1]);
        vector<double> temp2 = add_complex_num(y0[i][0], y0[i][1], temp1[0], temp1[1]);
        y[i] = vector<double>(2);
        y[i][0] = temp2[0];
        y[i][1] = temp2[1];
        vector<double> temp3 = add_complex_num(y0[i][0], y0[i][1], -temp1[0], -temp1[1]);
        y[i + (N/2)] = vector<double>(2);
        y[i + (N/2)][0] = temp3[0];
        y[i + (N/2)][1] = temp3[1];
    }
    return y;
}

//product polynomial function for calculating the product of the output
//terms of evaluated polynomials
//input:
//      poly_1_evaluations: evaluated 2D array generated from Eval function for first polynomial
//      poly_2_evaluations: evaluated 2D array generated from Eval function for second polynomial
//      N: maximum possible degree of output product polynomial
//output:
//      resultant 2D array after product of two arrays
vector<vector<double>> product_polynomial_evaluations(vector<vector<double>> poly_1_evaluations, vector<vector<double>> poly_2_evaluations, int N){
    vector<vector<double>> product_poly_evaluations(N);
    for(int i = 0; i < N; i++){
        vector<double> temp1 = multiply_complex_num(poly_1_evaluations[i][0], poly_1_evaluations[i][1], poly_2_evaluations[i][0], poly_2_evaluations[i][1]);
        product_poly_evaluations[i] = vector<double>(2);
        product_poly_evaluations[i][0] = temp1[0];
        product_poly_evaluations[i][1] = temp1[1];
    }
    return product_poly_evaluations;
}

//main function
int main(){
    int deg_1;
    cout<<"Enter the degree of the first polynomial: ";
    cin>>deg_1;
    vector<double> poly_1(MAX_DEGREE + 1);
    int i;
    cout<<"Enter the "<<(deg_1 + 1)<<" coefficients of the first polynomial in the increasing order of the degree of the monomials they belong to: ";
    for(i = 0; i <= MAX_DEGREE + 1; i++){
        if(i <= deg_1){
            double temp;
            cin>>temp;
            poly_1[i] = temp;
        } else {
            poly_1[i] = 0;
        }
    }
    int deg_2;
    cout<<"Enter the degree of the second polynomial: ";
    cin>>deg_2;
    vector<double> poly_2(MAX_DEGREE + 1);
    cout<<"Enter the "<<(deg_2 + 1)<<" coefficients of the second polynomial in the increasing order of the degree of the monomials they belong to: ";
    for(i = 0; i <= MAX_DEGREE + 1; i++){
        if(i <= deg_2){
            double temp;
            cin>>temp;
            poly_2[i] = temp;
        } else {
            poly_2[i] = 0;
        }
    }

    /*
    int deg_1 = 4;
    vector<double> poly_1 = {-1, 0, 3, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    int deg_2 = 3;
    vector<double> poly_2 = {0, 0, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    */

    cout<<"The first polynomial is: \n";
    print_poly(deg_1, poly_1);
    cout<<"The second polynomial is: \n";
    print_poly(deg_2, poly_2);

    cout<<"The product of the two polynomials obtained via naive polynomial multiplication is: \n";
    vector<double> naive_poly = naive_polynomial_multiplication(deg_1, deg_2, poly_1, poly_2);
    print_poly(deg_1 + deg_2, naive_poly);

    int N = find_N(deg_1, deg_2);

    vector<vector<double>> poly_1_evaluations = Eval(convert_complex(poly_1), N, false);

    vector<vector<double>> poly_2_evaluations = Eval(convert_complex(poly_2), N, false);

    vector<vector<double>> product_poly_evaluations = product_polynomial_evaluations(poly_1_evaluations, poly_2_evaluations, N);

    vector<vector<double>> final_eval = Eval(product_poly_evaluations, N, true);
    for(int i = 0; i < final_eval.size(); i++){
        final_eval[i][0] = final_eval[i][0]/N;
        final_eval[i][1] = final_eval[i][1]/N;
    }

    vector<double> fft_prod(2*MAX_DEGREE + 2, 0.0);
    for(int i = 0; i < N; i++){
        fft_prod[i] = round(final_eval[i][0]);
    }

    cout<<"The product of the two polynomials obtained via polynomial multiplication using FFT is: \n";
    print_poly(N, fft_prod);

    return 0;
}
